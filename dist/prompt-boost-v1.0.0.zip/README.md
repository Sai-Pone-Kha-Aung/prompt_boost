# ⚡ Prompt Boost Chrome Extension

A powerful Chrome extension that enhances your AI chat experience with saved prompts for ChatGPT, DeepSeek, Grok, and Gemini.

## 🚀 Features

- **📝 Prompt Management**: Save, edit, and organize your frequently used prompts
- **🎯 AI-Powered Prompt Improvement**: Automatically enhance your prompts using Google's Gemini AI for professional-grade prompt engineering
- **⚡ One-Click Insertion**: Insert prompts into AI chat interfaces with a single click
- **🎯 Multi-Platform Support**: Works with ChatGPT, DeepSeek, Grok, and Gemini
- **📱 Responsive Sidebar**: Clean, modern sidebar interface that doesn't interfere with your workflow
- **☁️ Cloud Sync**: Prompts sync across all your Chrome browsers using Chrome's storage
- **🎨 Beautiful UI**: Modern, gradient-based design with smooth animations
- **✨ Smart Enhancement**: Visual indicators for AI-improved prompts

## 🔧 Installation

### From Chrome Web Store (Recommended)

_Coming soon - will be published to Chrome Web Store_

### Manual Installation (Developer Mode)

1. Download or clone this repository
2. Open Chrome and go to `chrome://extensions/`
3. Enable "Developer mode" in the top right
4. Click "Load unpacked" and select the extension folder
5. The Prompt Boost extension should now appear in your toolbar

## 📖 How to Use

### Adding Prompts

1. Click the ⚡ Prompt Boost icon in your Chrome toolbar
2. Enter a descriptive title for your prompt
3. Enter the prompt content
4. Click "💾 Save Prompt"

### Using Prompts

1. Visit any supported AI platform:
   - ChatGPT (chat.openai.com)
   - DeepSeek (deepsider.ai)
   - Grok (x.ai)
   - Gemini (gemini.google.com)
2. You'll see the Prompt Boost sidebar on the right
3. Click any prompt title to insert it into the chat input
4. The prompt will be inserted and ready to send

### Managing Prompts

- **Edit**: Click the "Edit" button on any prompt to modify it
- **Delete**: Click the "Delete" button to remove prompts you no longer need
- **Improve**: Click the "🎯 Improve" button to enhance your prompt using AI
- **Toggle Sidebar**: Click the arrow button in the sidebar header to hide/show it

### AI Prompt Improvement

1. Click the "🎯 Improve" button on any saved prompt
2. The AI will analyze and enhance your prompt using best practices:
   - Adding role assignments for better context
   - Structuring for clarity and effectiveness
   - Adding step-by-step thinking for complex tasks
   - Improving specificity and examples
   - Optimizing for AI understanding
3. Improved prompts are marked with a ✨ indicator and green styling

## 🎯 Supported Platforms

- ✅ **ChatGPT** - chat.openai.com
- ✅ **DeepSeek** - deepsider.ai
- ✅ **Grok** - x.ai
- ✅ **Gemini** - gemini.google.com

## 🛠️ Technical Details

### Built With

- **Frontend**: HTML, CSS, JavaScript (Vanilla)
- **Storage**: Chrome Storage Sync API
- **Architecture**: Manifest V3 Chrome Extension

### File Structure

```
prompt_boost/
├── manifest.json          # Extension configuration
├── popup.html            # Popup interface
├── popup.js              # Popup functionality
├── content.js            # Content script for sidebar
├── content.css           # Sidebar styles
├── icons/                # Extension icons
│   ├── icon16.png
│   ├── icon48.png
│   ├── icon128.png
│   └── icon.svg
└── README.md             # This file
```

### Key Features Implementation

- **Content Script Injection**: Automatically injects sidebar into supported AI platforms
- **Dynamic Input Detection**: Intelligently finds and targets AI chat input fields
- **Storage Synchronization**: Real-time sync between popup and sidebar
- **Responsive Design**: Adapts to different screen sizes and layouts

## 🔒 Privacy & Security

- **No Data Collection**: We don't collect, store, or transmit any personal data
- **Local Storage**: All prompts are stored locally in Chrome's secure storage
- **Minimal Permissions**: Only requests necessary permissions for core functionality
- **No External Servers**: Extension works entirely offline

## 🤝 Contributing

Contributions are welcome! Here's how you can help:

1. **Fork** the repository
2. **Create** a feature branch (`git checkout -b feature/amazing-feature`)
3. **Commit** your changes (`git commit -m 'Add amazing feature'`)
4. **Push** to the branch (`git push origin feature/amazing-feature`)
5. **Open** a Pull Request

### Development Setup

```bash
# Clone the repository
git clone https://github.com/yourusername/prompt-boost.git
cd prompt-boost

# Load in Chrome for testing
# 1. Go to chrome://extensions/
# 2. Enable Developer mode
# 3. Click "Load unpacked" and select this folder
```

## 📋 Roadmap

### Version 1.1 (Planned)

- [ ] Prompt categories and tags
- [ ] Import/export prompts as JSON
- [ ] Keyboard shortcuts
- [ ] Prompt templates library

### Version 1.2 (Planned)

- [ ] AI-powered prompt suggestions
- [ ] Custom prompt variables
- [ ] Prompt history and usage analytics
- [ ] Dark mode support

### Version 2.0 (Future)

- [ ] Team collaboration features
- [ ] Advanced prompt templates
- [ ] Integration with more AI platforms
- [ ] Prompt performance analytics

## 🐛 Bug Reports & Feature Requests

Found a bug or have a feature request? Please create an issue on GitHub:

1. Go to the [Issues](https://github.com/yourusername/prompt-boost/issues) page
2. Click "New Issue"
3. Choose the appropriate template
4. Provide detailed information

## 📄 License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## 🙏 Acknowledgments

- Built with ❤️ for the AI community
- Inspired by the need for better prompt management tools
- Thanks to all contributors and users who provide feedback

## 📞 Support

Need help? Here are your options:

- 📚 Check the [FAQ](https://github.com/yourusername/prompt-boost/wiki/FAQ)
- 🐛 Report bugs via [GitHub Issues](https://github.com/yourusername/prompt-boost/issues)
- 💬 Join our [Discord community](https://discord.gg/prompt-boost) _(coming soon)_
- 📧 Email us at support@prompt-boost.com _(coming soon)_

---

**Made with ⚡ by the Prompt Boost team**

_Supercharge your AI conversations, one prompt at a time._
