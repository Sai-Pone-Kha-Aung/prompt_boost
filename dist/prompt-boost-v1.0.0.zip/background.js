// Background script for Prompt Boost extension
// Handles prompt improvement requests using the Gemini API

// Gemini API configuration
const GEMINI_API_URL =
  "https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash-latest:generateContent";

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === "improvePrompt") {
    handlePromptImprovement(request.promptText, request.title, request.apiKey)
      .then((result) => sendResponse(result))
      .catch((error) => sendResponse({ success: false, error: error.message }));

    // Return true to indicate we will send a response asynchronously
    return true;
  }

  // Handle ping for testing
  if (request.action === "ping") {
    sendResponse({ success: true, message: "Background script is active" });
    return true;
  }
});

async function handlePromptImprovement(promptText, title, apiKey) {
  try {
    console.log("Starting prompt improvement for:", title);

    // Validate API key
    if (!apiKey || !apiKey.trim()) {
      throw new Error("API key is required");
    }

    // Call the Gemini API to improve the prompt
    const improvedContent = await callGeminiAPI(promptText, title, apiKey);

    return {
      success: true,
      improvedText: improvedContent.improvedText,
      improvedTitle: improvedContent.improvedTitle,
      originalText: promptText,
      originalTitle: title,
    };
  } catch (error) {
    console.error("Error in handlePromptImprovement:", error);
    return {
      success: false,
      error: error.message,
    };
  }
}

async function callGeminiAPI(promptText, title, apiKey) {
  // Create the improvement prompt for Gemini
  const improvementPrompt = `You are an expert prompt engineer. Your task is to improve the following prompt to make it more effective, clear, and produce better results when used with AI systems.

Original Title: "${title}"
Original Prompt: "${promptText}"

Please improve this prompt by:
1. Making it more specific and clear
2. Adding better context if needed
3. Using optimal prompt engineering techniques (few-shot examples, step-by-step thinking, role assignment, etc.)
4. Ensuring it's structured for better AI understanding
5. Maintaining the original intent while enhancing effectiveness

Provide your response in this exact format:
IMPROVED_TITLE: [Your improved title here]
IMPROVED_PROMPT: [Your improved prompt here]

Guidelines:
- Keep the core purpose intact
- Make it more actionable and specific
- Add relevant context or examples if beneficial
- Use clear, direct language
- Structure it for optimal AI performance
- Ensure it's concise yet comprehensive

Remember to always start your response with "IMPROVED_TITLE:" followed by the improved title, then "IMPROVED_PROMPT:" followed by the improved prompt.`;

  try {
    const response = await fetch(`${GEMINI_API_URL}?key=${apiKey}`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        contents: [
          {
            parts: [
              {
                text: improvementPrompt,
              },
            ],
          },
        ],
        generationConfig: {
          temperature: 0.7,
          topK: 40,
          topP: 0.95,
          maxOutputTokens: 2048,
        },
      }),
    });

    if (!response.ok) {
      throw new Error(
        `Gemini API request failed: ${response.status} ${response.statusText}`
      );
    }

    const data = await response.json();

    if (
      !data.candidates ||
      !data.candidates[0] ||
      !data.candidates[0].content
    ) {
      throw new Error("Invalid response from Gemini API");
    }

    const generatedText = data.candidates[0].content.parts[0].text;
    console.log("Gemini API response:", generatedText);

    // Parse the response to extract improved title and prompt
    const parsed = parseGeminiResponse(generatedText);

    return {
      improvedText: parsed.improvedPrompt,
      improvedTitle: parsed.improvedTitle,
    };
  } catch (error) {
    console.error("Error calling Gemini API:", error);
    throw new Error(`Failed to improve prompt with Gemini: ${error.message}`);
  }
}

function parseGeminiResponse(responseText) {
  // Initialize default values
  let improvedTitle = "";
  let improvedPrompt = "";

  try {
    // Split the response into lines for parsing
    const lines = responseText.split("\n");
    let currentSection = null;
    let titleLines = [];
    let promptLines = [];

    for (const line of lines) {
      const trimmedLine = line.trim();

      if (trimmedLine.startsWith("IMPROVED_TITLE:")) {
        currentSection = "title";
        const titleContent = trimmedLine.replace("IMPROVED_TITLE:", "").trim();
        if (titleContent) {
          titleLines.push(titleContent);
        }
      } else if (trimmedLine.startsWith("IMPROVED_PROMPT:")) {
        currentSection = "prompt";
        const promptContent = trimmedLine
          .replace("IMPROVED_PROMPT:", "")
          .trim();
        if (promptContent) {
          promptLines.push(promptContent);
        }
      } else if (
        currentSection === "title" &&
        trimmedLine &&
        !trimmedLine.startsWith("IMPROVED_PROMPT:")
      ) {
        titleLines.push(trimmedLine);
      } else if (currentSection === "prompt" && trimmedLine) {
        promptLines.push(trimmedLine);
      }
    }

    // Join the collected lines
    improvedTitle = titleLines.join(" ").trim();
    improvedPrompt = promptLines.join("\n").trim();

    // Fallback parsing if the structured format wasn't found
    if (!improvedTitle || !improvedPrompt) {
      // Try regex-based parsing as fallback
      const titleMatch = responseText.match(
        /IMPROVED_TITLE:\s*(.+?)(?=IMPROVED_PROMPT:|$)/s
      );
      const promptMatch = responseText.match(/IMPROVED_PROMPT:\s*(.+)$/s);

      if (titleMatch) {
        improvedTitle = titleMatch[1].trim();
      }
      if (promptMatch) {
        improvedPrompt = promptMatch[1].trim();
      }
    }

    // Final fallback - if still no structured response, extract meaningful content
    if (!improvedTitle || !improvedPrompt) {
      console.warn(
        "Could not parse structured response, using fallback extraction"
      );

      // Try to extract any title-like content (first line or short sentence)
      const firstLines = responseText
        .split("\n")
        .filter((line) => line.trim().length > 0);
      if (firstLines.length > 0 && firstLines[0].length < 100) {
        improvedTitle = firstLines[0]
          .trim()
          .replace(/^(Title:|TITLE:|Improved Title:)/i, "")
          .trim();
      }

      // Use the entire response as the improved prompt if no clear structure
      if (!improvedPrompt) {
        improvedPrompt = responseText.trim();
      }
    }

    // Clean up any remaining formatting artifacts
    improvedTitle = improvedTitle.replace(/^["']|["']$/g, "").trim();
    improvedPrompt = improvedPrompt.replace(/^["']|["']$/g, "").trim();

    console.log("Parsed response:", {
      improvedTitle,
      improvedPrompt: improvedPrompt.substring(0, 100) + "...",
    });

    return {
      improvedTitle: improvedTitle || "Improved Prompt",
      improvedPrompt: improvedPrompt || responseText.trim(),
    };
  } catch (error) {
    console.error("Error parsing Gemini response:", error);

    // Fallback to using the original response
    return {
      improvedTitle: "Improved Prompt",
      improvedPrompt: responseText.trim(),
    };
  }
}
